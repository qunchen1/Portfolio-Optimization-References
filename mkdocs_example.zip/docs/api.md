# API Reference

::: mycalculator.calculator
