# Welcome to MyCalculator

This is a simple calculator library in Python.

## Installation

```bash
pip install mycalculator
```

## Usage

```python
from mycalculator.calculator import add, subtract

print(add(2, 3))       # 5
print(subtract(5, 2))  # 3
```
